const properties = [
  {
    header: ['Фотографія', 'Фотография', 'Photography'],
    class: 'fas fa-camera-retro',
    properties: '90%'
  },
  {
    header: ['Ретуш', 'Ретушь', 'Retouch'],
    class: 'fas fa-paint-brush',
    properties: '85%'
  }
];

export { properties };