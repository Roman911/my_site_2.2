const barItem = [
  {
    subtitle: '6+',
    text: ['Років', 'Лет', 'Years']
  },
  {
    subtitle: '26+',
    text: ['Фотосесій', 'Фотосессий', 'Photosession']
  },
  {
    subtitle: '11+',
    text: ['Щасливих клієнтів', 'Щасливых клыентов', 'Happy Clients']
  }
];

export { barItem };