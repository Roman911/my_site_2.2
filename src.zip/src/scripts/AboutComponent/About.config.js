const contentItem = [
  {
    aboutMe: ['про мене', 'обо мне', 'about me'],
    lovePhoto: ['Я люблю фотографувати', 'Я люблю фотографировать', 'I love photography'],
    text: [
      'Ласкаво прошу на мій сайт! Мене звати Роман. Я займаюсь фотозйомкою більше 5 років. Фотографія для мене - це спосіб зафіксувати момент життя, впіймати емоцію і настрій. Фотографії - це те, що останеться з вами на все життя, те, що ви будете показувати своїм дітям і внукам. Саме тому я з великою увагою підхожу до їхнього створення. Головна задача для мене – це зберегти неповторні моменти вашого життя. Особливість моменту, щирість емоції, красиве світло і композиція — це основні складові хорошої фотографії, на мій погляд.',
      'Добро пожаловать на мой сайт! Меня зовут Роман. Я занимаюсь фотосъёмкой более 5 лет. Фотография для меня - это способ запечатлеть мгновение жизни, уловить эмоцию и настроение. Фотографии - это то, что останется с вами на всю жизнь, то, что вы будете показывать своим детям и внукам. Именно поэтому я с большим вниманием подхожу к их созданию. Главная задача для меня – это сохранить неповторимые моменты вашей жизни. Уникальность момента, искренние эмоции, красивый свет и композиция — вот основные составляющие хорошей фотографии, на мой взгляд.',
      'We have created a fictional "personal" website/blog, and our fictional character is a hobby photographer. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
    ],
    title: ['Мене звати:','Меня зовут:','My Name:'],
    name: ['Роман Лисик', 'Роман Лысык', 'Roman Lysyk'],
    text2: [
      'Особливість моменту, щирість емоції, красиве світло і композиція — це основні складові хорошої фотографії, на мій погляд. Кожний проект для мене художньо особливий і має виключно індивідуально-творчий підхід. Те, чим я займаюсь це історія до якої можна доторкнутися крізь час. Це те, що ніколи не старіє і немає терміну дії…',
      'Уникальность момента, искренние эмоции, красивый свет и композиция — вот основные составляющие хорошей фотографии, на мой взгляд. Каждый проект для меня художественно особенный и имеет исключительно индивидуально-творческой подход. То, чем я занимаюсь это история к которой можно дотронутся сквозь время. Это то, что некогда не стареет, не имеет срока годности…',
      'Welcome to my website. I am lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'
    ],
    subtitle: ['Я дійсно хороший в:', 'Я действительно хорош в:', 'Im really good at:']
  }
];

export { contentItem };