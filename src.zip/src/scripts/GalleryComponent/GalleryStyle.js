import { StyleSheet } from 'aphrodite/no-important';

export default StyleSheet.create({
  gallery: {
    boxSizing: 'border-box',
    minHeight: '75vh'
  }
});