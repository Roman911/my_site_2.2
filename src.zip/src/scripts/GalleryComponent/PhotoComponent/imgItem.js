const imgItem = [
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_001.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_001.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_002.jpg'
  },
  {
    imgUrl: './photo_m_001.jpg'
  }
];

export { imgItem }