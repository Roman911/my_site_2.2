const photoItem = [
  {
    header: ['Мої роботи', 'Мои работи', 'MY WORK'],
    subtitle: [
      'Ось деякі з моїх останіх робіт.',
      'Вот несколько с моих последних работ.',
      'Here are some of my latest.'
    ],
    text: [
      'Натисніть на зображення, щоб збільшити його',
      'Нажмите на изображенние, чтоб увеличить его',
      'Click on the images to make them bigger'
    ]
  }
];

export { photoItem };