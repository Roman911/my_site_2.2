import React, { Component } from 'react';
import { imgItem } from "./imgItem";

import { css } from 'aphrodite/no-important';
import gridStyles from './../../../styles/gridStyles';
import styles from './ColumnStyle';
import {ModalComponent} from "./ModalComponent";

class ColumnComponent extends Component {
  constructor() {
    super();
    const imgUrl = imgItem.map((item) => {
      return item.imgUrl
    });
    this.state = {
      modal: false,
      modalImg: 0,
      images: imgUrl,
      currentIndex: 0,
      res: false
    }
  }

  setModal(visible, index, length) {
    this.setState({modalImg: this.state.images[index]});
    this.setState({modal: visible});
    this.setState({currentIndex: index});
    this.setState({length: length});
    document.body.style.overflow = 'hidden';
  }

  render() {

    const imgK = imgItem.map((item, index) => {
      let img ;
      if (index === 0) {
        img = item;
      }
      return img || !undefined ;
    });

    console.log(imgK);


    const imgColumn1 = imgItem.map((item, index) => {
      return <div key={index} className={css(styles.item)} >
        <img
          className={css(styles.img)}
          src={item.imgUrl}
          alt=""
          onClick={() => this.setModal(true, index, imgItem.length)}
        />
      </div>
    });

    let grids;
    if (window.matchMedia("(max-width: 576px)").matches) {
      grids = [
        <div className={css(gridStyles.width100)}>{ imgK }</div>
      ];
    } else if (window.matchMedia("(max-width: 768px)").matches) {
      grids = [
        <div className={css(gridStyles.width50)}>{ imgK }</div>,
        <div className={css(gridStyles.width50)}>{ imgK }</div>
      ];
    } else {
      grids = [
        <div className={css(gridStyles.width25)}>{ imgK }</div>,
        <div className={css(gridStyles.width25)}>{ imgK }</div>,
        <div className={css(gridStyles.width25)}>{ imgK }</div>,
        <div className={css(gridStyles.width25)}>{ imgK }</div>
      ];
    }

    return <div className={css(gridStyles.gridContainer)}>
      { grids }
      <ModalComponent />
    </div>
  }
}

export { ColumnComponent };