import React, { Component } from 'react';

class ModalComponent extends Component {
  render() {
    return <div>
      fgh
    </div>
  }
}

export { ModalComponent };