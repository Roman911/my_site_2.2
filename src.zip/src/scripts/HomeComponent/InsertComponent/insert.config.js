const insertItem = [
  {
    name: ['портфоліо', 'портфолио', 'portfolio'],
    name2: ['контакти', 'контакты', 'contacts']
  }
];

export { insertItem };